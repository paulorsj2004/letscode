package rentacar.payment;

public interface IPaymentMethod<T> {

    public boolean validateMethod(T obj);

    public boolean pay(T obj);

}
