package rentacar.payment;

public abstract class PaymentMethod<T> implements IPaymentMethod<T> {

    private String nome;

    @Override
    public boolean validateMethod(T obj) {
        return false;
    }

    @Override
    public boolean pay(T obj) {
        return false;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public PaymentMethod(String nome) {
        this.nome = nome;
    }
}
