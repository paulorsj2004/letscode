package rentacar.payment;

public class CreditCard extends PaymentMethod<CreditCard> {

    private String nrCard;
    private String dtExpirate;
    private int cvv;
    private String flag;

    public String getNrCard() {
        return nrCard;
    }

    public void setNrCard(String nrCard) {
        this.nrCard = nrCard;
    }

    public String getDtExpirate() {
        return dtExpirate;
    }

    public void setDtExpirate(String dtExpirate) {
        this.dtExpirate = dtExpirate;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    @Override
    public String toString() {
        return "CreditCard [nome=" + super.getNome() + ",nrCard=" + nrCard + ", dtExpirate=" + dtExpirate + ", cvv="
                + cvv + ", flag=" + flag + "]";
    }

    @Override
    public boolean pay(CreditCard obj) {
        System.out.println("++++++++ pagando o cartao " + obj.getNrCard() + " - CVV : " + obj.getCvv() + " - Bandeira: "
                + obj.getFlag() + " - nome : " + obj.getNome());
        System.out.println();
        System.out.println("============ Pagamento realizado ! =========================");
        return true;
    }

    @Override
    public boolean validateMethod(CreditCard cc) {

        if (this.cvv == 0) {
            System.out.println("CVV inválido !");
            return false;
        }

        if (this.dtExpirate.length() == 0) {
            System.out.println("Data de expiração inválida !");
            return false;
        }

        if (this.flag.length() == 0) {
            System.out.println("Bandeira é requirido !");
            return false;
        }

        if (this.nrCard.length() == 0) {
            System.out.println("Número do cartão é requirido !");
            return false;
        }

        return true;
    }

    public CreditCard(String nome, String nrCard, String dtExpirate, int cvv, String flag) {
        super(nome);
        this.nrCard = nrCard;
        this.dtExpirate = dtExpirate;
        this.cvv = cvv;
        this.flag = flag;
    }

}
