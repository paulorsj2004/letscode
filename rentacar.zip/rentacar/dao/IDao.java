package rentacar.dao;

public interface IDao<T> {

    public boolean inserir(T objeto);

    public boolean atualizar(T objeto);

    public boolean excluir(T objeto);

    public T selecionarPorId(int id);

}
