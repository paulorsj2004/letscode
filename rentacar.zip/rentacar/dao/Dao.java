package rentacar.dao;

import java.util.ArrayList;
import java.util.List;

public class Dao<T> implements IDao<T> {

    List<T> listas = new ArrayList<T>();

    @Override
    public boolean inserir(T objeto) {

        listas.add(objeto);
        return true;
    }

    @Override
    public boolean atualizar(T objeto) {
        listas.remove(objeto);
        return listas.add(objeto);

    }

    @Override
    public boolean excluir(T objeto) {
        return listas.remove(objeto);
    }

    @Override
    public T selecionarPorId(int id) {
        return null;
    }

    public List<T> getLista() {
        return this.listas;
    }

}
