package rentacar;

import java.nio.ShortBuffer;
import java.time.LocalDate;

import javax.sound.midi.Soundbank;

import rentacar.dao.Dao;
import rentacar.model.Aluguel;
import rentacar.model.Carro;
import rentacar.model.Cliente;
import rentacar.model.Funcionario;
import rentacar.payment.CreditCard;

public class TesteLocadora {

    public static void main(String[] args) {

        System.out.println("######### Cadastrando carros para alugar ######################");
        System.out.println();

        Carro car1 = new Carro(1, "JFL-8282", 2001, "CORSA", "GM", 1200.0, 50.0);
        Carro car2 = new Carro(2, "JJW-2982", 2012, "COROLLA", "TOYOTA", 10000.0, 100.0);
        Carro car3 = new Carro(3, "PAB-3420", 2014, "PRISMA", "GM", 15000.0, 80.0);

        Dao<Carro> d = new Dao<Carro>();
        d.inserir(car1);
        d.inserir(car2);
        d.inserir(car3);

        for (Carro c : d.getLista()) {
            System.out.println(c.toString());
        }

        System.out.println();
        System.out.println("######### Atualizando modelo de carro COROLLA ######################");
        System.out.println();

        car2.setModelo("Corolla XSR");
        d.atualizar(car2);

        for (Carro c : d.getLista()) {
            System.out.println(c.toString());
        }

        System.out.println("######### Corolla atualizado ######################");
        System.out.println();

        CreditCard cartaoCredito = new CreditCard("Paulo r souza jr", "12345678", "11/28", 123, "Visa");
        CreditCard cartaoCreditoJulia = new CreditCard("Julia Leal", "57684345", "10/24", 521, "Master");

        System.out.println("######### Cadastrando cliente... ######################");
        System.out.println();

        Cliente paulo = new Cliente("826115234", "Paulo Roberto", LocalDate.of(1979, 12, 30), 123456, "Brasilia", "df");
        Cliente maria = new Cliente("348651234", "Maria do Carmo", LocalDate.of(1959, 8, 23), 874509, "Recife", "pe");
        Cliente julia = new Cliente("011759098", "Julia de Souza", LocalDate.of(2004, 5, 12), 212357, "Belem", "pa");

        System.out.println("######### Adicionando cartão de credito a carteira de " + paulo.getNome()
                + "... ######################");
        System.out.println();
        paulo.adicionarMetodoPagamento(cartaoCredito);

        System.out.println("######### Adicionando cartão de credito a carteira de " + julia.getNome()
                + "... ######################");
        System.out.println();
        julia.adicionarMetodoPagamento(cartaoCreditoJulia);

        Dao<Cliente> clienteDao = new Dao<Cliente>();
        clienteDao.inserir(paulo);
        clienteDao.inserir(maria);
        clienteDao.inserir(julia);

        for (Cliente cli : clienteDao.getLista()) {
            System.out.println(cli.toString());
        }

        System.out.println("######### Clientes cadastrados ######################");
        System.out.println();

        System.out.println("######### Cadastrando funcionarios para atendimento... ######################");
        System.out.println();

        Dao<Funcionario> funcionarioDao = new Dao<Funcionario>();
        Funcionario func1 = new Funcionario("674908234", "Joao Marcos da Silva", LocalDate.of(1969, 4, 10), "f345234",
                "Atendente", 1200);
        Funcionario func2 = new Funcionario("452789563", "Marley Batista", LocalDate.of(1975, 2, 1), "f800120",
                "Atendente", 1500);
        funcionarioDao.inserir(func1);
        funcionarioDao.inserir(func2);

        for (Funcionario func : funcionarioDao.getLista()) {
            System.out.println(func.toString());
        }

        System.out.println("######### Funcionarios cadastrados ######################");
        System.out.println();

        System.out.println("Validacao do cartao : " + paulo.getCarteira().get(0));
        System.out.println();

        System.out.println("############### cliente " + paulo.getNome() + " quer alguar o carro " + car2.getMarca()
                + "/" + car2.getModelo() + " ###########");

        System.out.println();
        System.out.println("############# Alugando .....  ###################### ");

        System.out.println();
        System.out.println("############# " + func1.getNome() + " atenderá o cliente " + paulo.getNome()
                + " .....  ###################### ");

        Dao<Aluguel> aluguelDao = new Dao<Aluguel>();
        Aluguel alugaCorollaParaPaulo = new Aluguel(10, car2, func1, cartaoCredito, paulo);

        if (alugaCorollaParaPaulo.confimarAluguel()) {
            aluguelDao.inserir(alugaCorollaParaPaulo);
        }

        System.out.println("Validacao do cartao : " + julia.getCarteira().get(0));
        System.out.println();

        System.out.println("############### cliente " + julia.getNome() + " quer alguar o carro " + car3.getMarca()
                + "/" + car2.getModelo() + " ###########");

        System.out.println();
        System.out.println("############# Alugando .....  ###################### ");

        System.out.println();
        System.out.println("############# " + func2.getNome() + " atenderá o cliente " + julia.getNome()
                + " .....  ###################### ");

        System.out.println("############### cliente " + julia.getNome() + " quer alguar o carro " + car3.getMarca()
                + "/" + car2.getModelo() + " ###########");

        Aluguel alugaCorollaParaJulia = new Aluguel(5, car3, func2, cartaoCreditoJulia, julia);

        if (alugaCorollaParaJulia.confimarAluguel()) {
            aluguelDao.inserir(alugaCorollaParaJulia);
        }

        System.out.println();
        System.out.println("===================== histórico de alugueis =====================================");
        System.out.println();

        for (Aluguel histAluguel : aluguelDao.getLista()) {
            System.out.println(histAluguel.toString());
        }
    }

}
