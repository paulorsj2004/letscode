package rentacar.model;

public abstract class Veiculo {

    private int nrRegistro;
    private String placa;
    private int anoFabricacao;
    private String modelo;
    private String marca;
    private double quilometragem;
    private double valorDiaria;

    public Veiculo(int nrRegistro, String placa, int anoFabricacao, String modelo, String marca, double quilometragem,
            double valorDiaria) {
        this.nrRegistro = nrRegistro;
        this.placa = placa;
        this.anoFabricacao = anoFabricacao;
        this.modelo = modelo;
        this.marca = marca;
        this.valorDiaria = valorDiaria;
    }

    public void setNrRegistro(int nrRegistro) {
        this.nrRegistro = nrRegistro;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public void setAnoFabricacao(int anoFabricacao) {
        this.anoFabricacao = anoFabricacao;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setQuilometragem(double quilometragem) {
        this.quilometragem = quilometragem;
    }

    public int getNrRegistro() {
        return nrRegistro;
    }

    public String getPlaca() {
        return placa;
    }

    public int getAnoFabricacao() {
        return anoFabricacao;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMarca() {
        return marca;
    }

    public double getQuilometragem() {
        return quilometragem;
    }

    @Override
    public String toString() {
        return "Veiculo [nrRegistro=" + nrRegistro
                + ", placa=" + placa
                + ", anoFabricacao=" + anoFabricacao
                + ", modelo=" + modelo
                + ", marca=" + marca
                + ", quilometragem=" + quilometragem
                + ", valorDiaria=" + valorDiaria
                + "]";
    }

    public double getValorDiaria() {
        return valorDiaria;
    }

    public void setValorDiaria(double valorDiaria) {
        this.valorDiaria = valorDiaria;
    }

}
