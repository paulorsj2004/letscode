package rentacar.model;

public class Caminhao extends Veiculo {

    double cargaMaxima;
    final String UNIDADEMEDIDA = "Ton.";

    public Caminhao(int nrRegistro, String placa, int anoFabricacao, String modelo, String marca,
            double quilometragem, double cargaMaxima, double valorDiaria) {
        super(nrRegistro, placa, anoFabricacao, modelo, marca, quilometragem, valorDiaria);
        this.cargaMaxima = cargaMaxima;
    }

}
