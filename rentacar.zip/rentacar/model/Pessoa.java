package rentacar.model;

import java.time.LocalDate;

public abstract class Pessoa {

    private String nrCpf;
    private String nome;
    private LocalDate dtNascimento;

    public Pessoa(String nrCpf, String nome, LocalDate dtNascimento) {
        this.nrCpf = nrCpf;
        this.nome = nome;
        this.dtNascimento = dtNascimento;
    }

    public String getNrCpf() {
        return nrCpf;
    }

    public void setNrCpf(String nrCpf) {
        this.nrCpf = nrCpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public LocalDate getDtNascimento() {
        return dtNascimento;
    }

    public void setDtNascimento(LocalDate dtNascimento) {
        this.dtNascimento = dtNascimento;
    }

    @Override
    public String toString() {
        return "Pessoa [nrCpf=" + nrCpf + ", nome=" + nome + ", dtNascimento=" + dtNascimento.toString() + "]";
    }

}
