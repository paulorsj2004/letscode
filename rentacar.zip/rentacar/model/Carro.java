package rentacar.model;

public class Carro extends Veiculo {

    private int qtdPortas;
    private double valorDiaria;

    public Carro(int nrRegistro, String placa, int anoFabricacao, String modelo, String marca, double quilometragem,
            double valorDiaria) {
        super(nrRegistro, placa, anoFabricacao, modelo, marca, quilometragem, valorDiaria);
        this.setQuilometragem(quilometragem);
        this.qtdPortas = 4;
    }

    public int getQtdPortas() {
        return qtdPortas;
    }

    public void setQtdPortas(int qtdPortas) {
        this.qtdPortas = qtdPortas;
    }

    @Override
    public String toString() {

        return "Carro [qtdPortas=" + this.qtdPortas + ", nrRegistro=" + super.getNrRegistro() + ", placa="
                + super.getPlaca()
                + ", anoFabricacao="
                + super.getAnoFabricacao()
                + ", modelo=" + super.getModelo() + ", marca=" + super.getMarca() + ", quilometragem="
                + super.getQuilometragem()
                + ", valorDiaria=" + this.valorDiaria
                + "]";
    }

}
