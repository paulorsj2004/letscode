package rentacar.model;

import rentacar.dao.Dao;
import rentacar.payment.PaymentMethod;

public class Aluguel {

    private int qtdDiarias = 0;
    private Veiculo veiculo;
    private Funcionario atendente;
    private PaymentMethod pagamento;
    private Cliente cliente;

    public Aluguel(int qtdDiarias, Veiculo veiculo, Funcionario atendente, PaymentMethod pagamento, Cliente cliente) {
        this.qtdDiarias = qtdDiarias;
        this.veiculo = veiculo;
        this.atendente = atendente;
        this.pagamento = pagamento;
        this.cliente = cliente;
    }

    public int getQtdDiarias() {
        return qtdDiarias;
    }

    public void setQtdDiarias(int qtdDiarias) {
        this.qtdDiarias = qtdDiarias;
    }

    public boolean confimarAluguel() {

        if (this.cliente == null) {
            System.out.println("Selecione um cliente!");
            return false;
        }

        if (this.atendente == null) {
            System.out.println("Selecione um funcionario para atendimento!");
            return false;
        }

        if (this.veiculo == null) {
            System.out.println("Selecione um Veiculo para aluguel!");
            return false;
        }

        if (this.qtdDiarias == 0) {
            System.out.println("Selecione quantiade de diárias !");
            return false;
        }

        if (this.pagamento == null) {
            System.out.println("Selecione um método de pagamento !");
            return false;
        }

        if (this.pagamento.validateMethod(pagamento)) {

            this.pagamento.pay(pagamento);

            System.out.println("Quantidade de diárias a ser cobrado : " + this.getQtdDiarias());
            System.out.println("Valor da dária : " + this.veiculo.getValorDiaria());
            System.out.println("Total a pagar :  " + (this.getQtdDiarias() * this.veiculo.getValorDiaria()));
            System.out.println();
            System.out.println("$$$$$$$$$$$$$$$$$$$ Processando pagamento do aluguel no valor de R$ : "
                    + (this.getQtdDiarias() * this.veiculo.getValorDiaria()));
            System.out.println();
            System.out.println("        ALGUEL CONFIRMADO COM SUCESSO, PAGAMENTO REALIZADO !! ");
        }

        return true;
    }

    @Override
    public String toString() {
        return "Aluguel [qtdDiarias=" + qtdDiarias + ",\n veiculo=" + veiculo.toString() + ",\n atendente="
                + atendente.toString()
                + ",\n pagamento=" + pagamento.toString() + ",\n cliente=" + cliente.toString() + "]";
    }

}
