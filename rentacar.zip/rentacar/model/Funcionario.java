package rentacar.model;

import java.time.LocalDate;

public class Funcionario extends Pessoa {

    private String matricula;
    private String funcao;
    private double salario;

    public String getMatricula() {
        return matricula;
    }

    public Funcionario(String nrCpf, String nome, LocalDate dtNascimento, String matricula, String funcao,
            double salario) {
        super(nrCpf, nome, dtNascimento);
        this.matricula = matricula;
        this.funcao = funcao;
        this.salario = salario;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    @Override
    public String toString() {
        return "Funcionario [matricula=" + matricula + ", funcao=" + funcao + ", salario=" + this.salario + ", cpf="
                + super.getNrCpf() + ", nome="
                + super.getNome() + ", dtNascimento=" + super.getDtNascimento().toString() + "]";
    }

}
