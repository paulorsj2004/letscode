package rentacar.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import rentacar.payment.PaymentMethod;

public class Cliente extends Pessoa {

    private int nrCNH;
    private String cidade;
    private String uf;
    private List<PaymentMethod> carteira;

    public Cliente(String nrCpf, String nome, LocalDate dtNascimento, int nrCNH, String cidade, String uf) {
        super(nrCpf, nome, dtNascimento);
        this.nrCNH = nrCNH;
        this.cidade = cidade;
        this.uf = uf;
        this.carteira = new ArrayList<PaymentMethod>();
    }

    public int getNrCNH() {
        return nrCNH;
    }

    public void setNrCNH(int nrCNH) {
        this.nrCNH = nrCNH;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getUf() {
        return uf;
    }

    public void setUf(String uf) {
        this.uf = uf;
    }

    public void adicionarMetodoPagamento(PaymentMethod payMeth) {
        this.carteira.add(payMeth);
    }

    @Override
    public String toString() {
        return "Cliente [nrCNH=" + this.nrCNH + ", cidade=" + this.cidade + ", uf=" + this.uf + ", cpf="
                + super.getNrCpf() + ", nome="
                + super.getNome() + ", dtNascimento=" + super.getDtNascimento().toString()
                + ", pagamento=" + ((this.carteira.size() > 0) ? this.carteira.get(0).toString() : "sem pagamento")
                + "]";
    }

    public List<PaymentMethod> getCarteira() {
        return this.carteira;
    }

}
